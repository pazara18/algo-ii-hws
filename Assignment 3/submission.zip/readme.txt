Working mode: 2
e2-files_as_main_parameters.t
For the ones who get the filenames as main arguments
but scores are not taken as parameters. Scores for match,
mismatch and gap are 1, -2 and -4 respectively for this case.